import React from 'react';
import { StyleSheet, SafeAreaView, View, ScrollView } from 'react-native';
import { Button } from 'react-native-elements';
import FormInput from './Form/FormInput';
import FormButton from './Form/FormButton';
import Fire from '../Fire'

export default class Form extends React.Component {
  state = {
    name: '',
    thumbnail: '',
    descrp: '',
    goals: '',
    topics: '',
    commt: '',
  };

  handleNameChange = (name) => {
    this.setState({ name });
  };
  handleThumbnailChange = (thumbnail) => {
    this.setState({ thumbnail });
  };
  handleDescrpChange = (descrp) => {
    this.setState({ descrp });
  };
  handleGoalsChange = (goals) => {
    this.setState({ goals });
  };
  handleTopicsChange = (topics) => {
    this.setState({ topics });
  };
  handleCommtChange = (commt) => {
    this.setState({ commt });
  };

  onSubmit = async () => {
    const { name, thumbnail, descrp, goals, topics, commt } = this.state;
    try {
      if (
        name.length > 0 &&
        descrp.length > 0 &&
        goals.length > 0 &&
        topics.length > 0 &&
        commt.length > 0
      ) {
        Fire.shared.sendForm(this.state)
        this.props.navigation.navigate("success");
      }
    } catch (err) {
      alert(err);
    }
  };

  render() {
    const { name, thumbnail, descrp, goals, topics, commt } = this.state;

    return (
      <ScrollView style={styles.container}>
        <SafeAreaView style={styles.container}>
          <FormInput
            name="name"
            value={name}
            placeholder="Project Name"
            onChangeText={this.handleNameChange}
            iconName="rename-box"
            iconColor="#2C384A"
          />
          <FormInput
            name="thumbnail"
            value={thumbnail}
            placeholder="thumbnail"
            onChangeText={this.handleThumbnailChange}
            iconName="file-image-outline"
            iconColor="#2C384A"
          />
          <FormInput
            name="descrp"
            value={descrp}
            placeholder="Project Description"
            onChangeText={this.handleDescrpChange}
            iconName="card-text-outline"
            iconColor="#2C384A"
          />
          <FormInput
            name="goals"
            value={goals}
            placeholder="Project Goals"
            onChangeText={this.handleGoalsChange}
            iconName="target"
            iconColor="#2C384A"
          />
          <FormInput
            name="topics"
            value={topics}
            placeholder="Related Topics Hashtag"
            onChangeText={this.handleTopicsChange}
            iconName="playlist-plus"
            iconColor="#2C384A"
          />
          <FormInput
            name="commt"
            value={commt}
            placeholder="Commitment Level"
            onChangeText={this.handleCommtChange}
            iconName="timer"
            iconColor="#2C384A"
          />
          <View style={styles.buttonContainer}>
            <FormButton
              buttonType="outline"
              onPress={this.onSubmit}
              title="SUBMIT PROJECT"
              buttonColor="#039BE5"
            />
          </View>
        </SafeAreaView>
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F1FFFA',
  },
  buttonContainer: {
    margin: 20,
  },
});
