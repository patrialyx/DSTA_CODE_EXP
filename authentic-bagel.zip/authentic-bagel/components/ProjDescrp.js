import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  Image,
  Dimensions,
} from 'react-native';
import Constants from 'expo-constants';
import Expo from 'expo';
import ProgressBarAnimated from 'react-native-progress-bar-animated';

export default class ProjectPage extends React.Component {
  render() {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: '#F1FFFA',
          justifyContent: 'center',
        }}>
        <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
          <Image
            style={styles.cardImage}
            source={require('./sunset.jpg')}
          />
        </View>
        <View style={{ margin: 10 }}>
          <Text style={styles.title}> Project Greenfingers </Text>
          <View style={{height: 20}} />
          <Text style={styles.subtext}>
            Greenfingers is a community effort to plant more plants and beautify
            our community!{'\n'}
          </Text>
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
          <Text style={styles.subtext}> No. of participants: 25 </Text>
          <Text style={styles.subtext}> End date: 18-02-21 {'\n'} </Text>
        </View>
        <View style={{ margin: 10 }}>
          <Text style={styles.buttonText}> Project progress {'\n'}</Text>
          <ProgressBarAnimated
            width={Dimensions.get('screen').width - 30}
            value={20}
            backgroundColorOnComplete="#6CC644"
          />
        </View>
        <View style={{height: 60}} />
        <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
          <JoinButton
            onPress={() => {
              alert('adds project to Build');
            }}
          />
        </View>
      </View>
    );
  }
}

const JoinButton = ({ onPress }) => {
  return (
    <View style={{ justifyContent: 'center' }}>
      <TouchableOpacity onPress={onPress} style={styles.buttonStyle}>
        <Text style={styles.buttonText}> Join </Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  buttonStyle: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 80,
    height: 40,
    backgroundColor: '#93B7BE',
    borderRadius: 25,
  },

  title: {
    alignItems: 'center',
    textAlign: 'center',
    height: 30,
    fontSize: 30,
  },

  subtext: {
    textAlign: 'left',
    fontSize: 14,
  },

  buttonText: {
    fontSize: 20,
    textAlignVertical: 'center',
    textAlign: 'center',
  },
  cardImage: {
    width: '50%',
    height: 100,
    resizeMode: 'stretch',
  },
});
