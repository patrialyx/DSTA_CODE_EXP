import React from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import Fire from '../Fire'

class Login extends React.Component {
  state = {
    name: '',
    checkName: false,
  };

  onPress = () => {
    if (this.state.checkName) {
      this.props.navigation.navigate('MainApp', { name: this.state.name });
    } else {
      alert('Please enter your name! (At least two characters)')
    }
  };

  checkName = () => {
    if (this.state.name.length > 0) {
      this.setState({ checkName: true });
    }
  };

  onChangeText = (name) => {
    this.checkName();
    this.setState({ name });
  };

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Enter your name:</Text>
        <TextInput
          onChangeText={this.onChangeText}
          style={styles.nameInput}
          placeHolder="Username"
          value={this.state.name}
        />
        <TouchableOpacity onPress={this.onPress}>
          <Text style={styles.buttonText}>Next</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const offset = 18;
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#F1FFFA',
    flex: 1,
    justifyContent: 'center',
  },
  nameInput: {
    height: offset * 2,
    margin: offset,
    paddingHorizontal: offset,
    borderColor: '#454545',
    borderWidth: 1,
  },
  title: {
    marginTop: offset,
    marginLeft: offset,
    fontSize: offset,
  },
  buttonText: {
    fontSize: offset,
    marginLeft: offset,
  },
});

export default Login;
