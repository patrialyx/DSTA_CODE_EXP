import * as React from 'react';
import { View, Text, Animated, StyleSheet, Dimensions } from 'react-native';
import { Button, Icon } from 'react-native-elements';
import ProgressBarAnimated from 'react-native-progress-bar-animated';

export default class App extends React.Component {
  state = {
    progress: 0,
    maxValue: 10,
  };

  change = (key, value) => {
    this.setState({
      [key]: this.state[key] + value,
    });
  };

  updateProgress = async () => {
    return this.state.progress;
  };

  render() {
    const barWidth = Dimensions.get('screen').width - 100;
    const progressCustomStyles = {
      backgroundColor: 'red',
      borderRadius: 0,
      borderColor: 'orange',
    };

    return (
      <View style={styles.container}>
        <View style={styles.main}>
          <Text style={styles.maintext}>Your Projects:</Text>
          <Text style={styles.text}>
            Project Greenfingers: {this.state.progress/this.state.maxValue} / {this.state.maxValue}{' '}
          </Text>
          <ProgressBarAnimated
            width={barWidth}
            value={this.state.progress}
            backgroundColorOnComplete="#6CC644"
          />
          <Text style={{ marginBottom: 10 }} />
          <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
            <Button
              raised
              title="Increase by 1!"
              onPress={() => this.change('progress', 100 / this.state.maxValue)}
            />
            <Button
              raised
              title="Decrease by 1!"
              onPress={() =>
                this.change('progress', -100 / this.state.maxValue)
              }
            />
          </View>
        </View>
        <View style={{ height: 10 }} />
        <View style={styles.main}>
          <Text style={styles.maintext}>
            You have not begun any projects! Explore or Create a new project
            now!
          </Text>
        </View>
        <View style={styles.bottom}>
          <Icon
            type="material-community"
            name="plus"
            reverse
            raised
            color="#93B7BE"
            reverseColor="#F1FFFA"
            onPress={() => this.props.navigation.navigate('form')}
          />
        </View>
      </View>
    );
  }
}

const pad = 24;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F1FFFA',
    padding: pad,
  },
  main: {
    padding: pad,
    backgroundColor: '#93B7BE',
    width: Dimensions.get('screen').width - pad * 2,
    borderWidth: 3,
    borderRadius: 20,
    borderColor: '#454545',
  },
  maintext: {
    fontSize: 32,
    textAlign: 'left',
    color: '#F1FFFA',
    marginBottom: 10,
  },
  text: {
    color: '#F1FFFA',
    textAlign: 'left',
    fontSize: 18,
    marginBottom: 10,
  },
  bottom: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
    marginRight: 5,
    marginBottom: 5,
  },
});
