import React from 'react';
import {
  Text,
  View,
  StyleSheet,
  Button,
  Image,
  TouchableOpacity,
} from 'react-native';

function ProfileButton({ onPress, title }) {
  return (
    <View style={{ justifyContent: 'center' }}>
      <TouchableOpacity onPress={onPress} style={styles.profileButton}>
        <Image
          style={styles.profileIcon}
          source={require('./male-profile-image.jpg')}
        />
      </TouchableOpacity>
    </View>
  );
}

function ReturnButton({ onPress }) {
  return (
    <View style={{ margin: 10 }}>
      <TouchableOpacity onPress={onPress} style={styles.returnButton}>
        <Text style={{ textAlign: 'center', padding: 2 }}> Return </Text>
      </TouchableOpacity>
    </View>
  );
}

export default class ProjectSuccess extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <View style={styles.headingContainer}>
          <Text style={styles.headingStyle}>
            You have successfully created your project!
          </Text>
        </View>
        <Text style={styles.subtext}> Here are some matching profiles: </Text>
        <View style={styles.horizontalButtons}>
          <ProfileButton
            onPress={() => {
              alert('Jios Profile 1');
            }}
            title="Profile 1"
          />
          <ProfileButton
            onPress={() => {
              alert('Jios Profile 2');
            }}
            title="Profile 2"
          />
          <ProfileButton
            onPress={() => {
              alert('Jios Profile 3');
            }}
            title="Profile 3"
          />
          <ProfileButton
            onPress={() => {
              alert('Jios Profile 4');
            }}
            title="Profile 4"
          />
        </View>
        <View style={{ padding: 10, alignItems: 'flex-end' }}>
          <Button
            title="Return"
            style={styles.returnButton}
            onPress={() => {
              this.props.navigation.navigate('build');
            }}
          />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#F1FFFA',
  },
  headingContainer: {
    backgroundColor: '#D5C7BC',
    padding: 10,
  },
  headingStyle: {
    fontSize: 30,
    textAlign: 'left',
    color: '#F1FFFA',
    padding: 10,
  },
  subtext: {
    margin: 10,
    fontSize: 18,
    color: '#454545',
    textAlign: 'left',
  },
  horizontalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    margin: 15,
  },
  profileButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#93B7BE',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileIcon: {
    width: 60,
    height: 60,
    resizeMode: 'cover',
    borderRadius: 30,
  },
  returnButton: {
    width: 80,
    height: 30,
    backgroundColor: '#93B7BE',
    borderRadius: 25,
  },
});
