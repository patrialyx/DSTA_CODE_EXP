import React, { Component } from 'react';
import { StyleSheet, ScrollView } from 'react-native';
import { Card, Button, Icon, Text } from 'react-native-elements';
import Fire from '../Fire';

function ProjectCard({ title, onPress, text }) {
  return (
    <Card
      title={title}
      image={require('./sunset.jpg')}
      containerStyle={{ marginBottom: 5 }}>
      <Text style={{ marginBottom: 10 }}>{text}</Text>
      <Button
        icon={<Icon name="code" color="#ffffff" />}
        buttonStyle={{
          borderRadius: 10,
          marginLeft: 10,
          marginRight: 10,
          marginBottom: 0,
        }}
        onPress={onPress}
        title="JOIN NOW"
      />
    </Card>
  );
}

export default class ExplorePage extends React.Component {
  state = {
    forms: [],
  };

  componentDidMount() {
    Fire.shared.formref.on('child_added', (querySnapshot) => {
      let {
        name,
        thumbnail,
        descrp,
        goals,
        topics,
        commt,
      } = querySnapshot.val() ? querySnapshot.val() : {};
      const { key: _id } = querySnapshot;
      this.setState((prevState) => ({
        forms: [
          ...prevState.forms,
          { _id, name, thumbnail, descrp, goals, topics, commt },
        ],
      }));
    });
  }

  componentWillUnmount() {
    Fire.shared.offForm();
  }

  render() {
    const onPress = () => {
      this.props.navigation.navigate('descrp');
    };
    return (
      <ScrollView style={styles.scrollView}>
        {this.state.forms.map((formData) => (
          <ProjectCard
            title={formData.name}
            key={formData._id}
            onPress={onPress}
            text={formData.descrp}
          />
        ))}
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  scrollView: {
    backgroundColor: '#F1FFFA',
    flex: 1,
  },
});
