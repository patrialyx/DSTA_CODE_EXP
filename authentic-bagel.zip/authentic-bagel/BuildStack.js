import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import BuildPage from './components/BuildPage';
import Form from './components/Form';
import Success from './components/ProjectSuccess';

const Stack = createStackNavigator();

const screenOptions = {
  headerStyle: {
    backgroundColor: '#93B7BE',
  },
  headerTintColor: '#F1FFFA',
};

function BuildStack() {
  return (
    <Stack.Navigator screenOptions={screenOptions} initialRouteName="build">
      <Stack.Screen
        name="build"
        component={BuildPage}
        options={{ title: 'KAMPONG' }}
      />
      <Stack.Screen
        name="form"
        component={Form}
        options={{ title: 'Create New Project' }}
      />
      <Stack.Screen
        name="success"
        component={Success}
        options={{ title: 'Project Created Successfully!', headerLeft: null }}
      />
    </Stack.Navigator>
  );
}

export default BuildStack;
