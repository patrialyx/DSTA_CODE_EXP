import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import Explore from './components/ExplorePage'
import Descrp from './components/ProjDescrp'

const Stack = createStackNavigator();

const screenOptions = {
  headerStyle: {
    backgroundColor: '#93B7BE',
  },
  headerTintColor: '#F1FFFA',
};

export default function ExploreStack() {
  return (
    <Stack.Navigator screenOptions={screenOptions} initialRouteName="explore">
      <Stack.Screen
        name="explore"
        component={Explore}
        options={{ title: 'Explore' }}
      />
      <Stack.Screen
        name="descrp"
        component={Descrp}
        options={{ title: 'Project Description' }}
      />
    </Stack.Navigator>
  );
}