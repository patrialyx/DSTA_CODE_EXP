import React from 'react';
import { Button, Text, View, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Constants from 'expo-constants';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import ChatStack from './ChatStack';
import BuildStack from './BuildStack';
import ExploreStack from './ExploreStack';

const Tab = createBottomTabNavigator();

const screenOptions = ({ route }) => ({
  tabBarIcon: ({ focused, color, size }) => {
    let iconName;

    if (route.name === 'Chat') {
      iconName = focused ? 'chat' : 'chat-outline';
    } else if (route.name == 'Build') {
      iconName = focused ? 'account-group' : 'account-group-outline';
    } else if (route.name == 'Explore') {
      iconName = focused ? 'lightbulb-on' : 'lightbulb-on-outline';
    }

    return <MaterialCommunityIcons name={iconName} size={size} color={color} />;
  },
});

const tabBarOptions = {
  activeTintColor: '#93B7BE',
  inactiveTintColor: '#454545',
};

export default function TabView() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        initialRouteName="Build"
        screenOptions={screenOptions}
        tabBarOptions={tabBarOptions}>
        <Tab.Screen name="Chat" component={ChatStack} />
        <Tab.Screen name="Build" component={BuildStack} />
        <Tab.Screen name="Explore" component={ExploreStack} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
