import React from 'react';
import { View, StyleSheet } from 'react-native';
import { GiftedChat } from 'react-native-gifted-chat';
import { createStackNavigator } from '@react-navigation/stack';

import Fire from './Fire';

class Chat extends React.Component {
  state = {
    messages: [],
  };

  get user() {
    return {
      _id: Fire.shared.uid,
    };
  }

  render() {
    return (
      <GiftedChat
        messages={this.state.messages}
        onSend={Fire.shared.send}
        user={this.user}
      />
    );
  }

  componentDidMount() {
    Fire.shared.onMsg((message) =>
      this.setState((previousState) => ({
        messages: GiftedChat.append(previousState.messages, message),
      }))
    );
  }

  componentWillUnmount() {
    Fire.shared.off();
  }
}

const Stack = createStackNavigator();

const screenOptions = {
  headerStyle: {
    backgroundColor: '#93B7BE',
  },
  headerTintColor: '#F1FFFA',
};

function ChatStack() {
  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen name="Chat!" component={Chat} />
    </Stack.Navigator>
  );
}

export default ChatStack;
