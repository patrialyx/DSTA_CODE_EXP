import * as React from 'react';
import { Text, View, StyleSheet, TouchableHighlight } from 'react-native';
import { createSwitchNavigator, NavigationContainer, createAppContainer } from 'react-navigation';
import Constants from 'expo-constants';
import Expo from 'expo';
import TabView from './TabView';
import Login from './components/Login';

class App extends React.Component {
  state = {
    isLoading: true,
  };

  checkLoading = () => {
    this.setState({ isLoading: false });
  };

  componentDidMount() {
    this.checkLoading();
  }

  render() {
    const { isLoading } = this.state;
    if (isLoading) {
      return (
        <View style={styles.container}>
          <Text style={styles.paragraph}>Loading your kampong...</Text>
        </View>
      );
    }
    return <TabView />;
  }
}

const MySwitchNavigator = createSwitchNavigator(
  {
  LoginScreen: Login,
  MainApp: App, 
  },
  {
    initialRouteName: 'LoginScreen',
  }
);


export default createAppContainer (MySwitchNavigator);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight + 50,
    backgroundColor: '#F1FFFA',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    color: '#454545',
    textAlign: 'center',
  },
});