import firebase from 'firebase';

class Fire {
  constructor() {
    this.init();
    this.observeAuth();
  }

  init = () => {
    if (!firebase.apps.length) {
      firebase.initializeApp({
        apiKey: 'AIzaSyClFUVgJ0N7RAZhtg1C3SRRfq9oaA61RNw',
        authDomain: 'codeexp-7282b.firebaseapp.com',
        databaseURL: 'https://codeexp-7282b.firebaseio.com',
        projectId: 'codeexp-7282b',
        storageBucket: 'codeexp-7282b.appspot.com',
        messagingSenderId: '958142479875',
      });
    }
  };

  observeAuth = () => firebase.auth().onAuthStateChanged(this.anonSign);

  anonSign = (user) => {
    try {
      firebase.auth().signInAnonymously();
    } catch ({ message }) {
      alert(message);
    }
  };

  get ref() {
    return firebase.database().ref('messages');
  }

  get formref() {
    return firebase.database().ref('form');
  }

  get uid() {
    return (firebase.auth().currentUser || {}).uid;
  }

  get timestamp() {
    return firebase.database.ServerValue.TIMESTAMP;
  }

  onMsg = (callback) =>
    this.ref
      .limitToLast(20)
      .on('child_added', (snapshot) => callback(this.parse(snapshot)));

  onForm = (callback) =>
    this.formref.on('child_added', (snapshot) =>
      callback(this.parseForm(snapshot))
    );

  send = (messages) => {
    for (let i = 0; i < messages.length; i++) {
      const { text, user } = messages[i];
      const message = {
        text,
        user,
        timestamp: this.timestamp,
      };
      this.append(message);
    }
  };

  sendForm = (form) => {
    const { name, thumbnail, descrp, goals, topics, commt } = form;
    const formSend = {
      name,
      thumbnail,
      descrp,
      goals,
      topics,
      commt,
    };
    this.formref.push(form);
  };

  append = (message) => this.ref.push(message);

  off() {
    this.ref.off();
  }

  offForm() {
    this.formref.off();
  }

  parse = (snapshot) => {
    const { timestamp: numberStamp, text, user } = snapshot.val();
    const { key: _id } = snapshot;

    const timestamp = new Date(numberStamp);

    const message = {
      _id,
      timestamp,
      text,
      user,
    };
    return message;
  };

  parseForm = (snapshot) => {
    const { name, thumbnail, descrp, goals, topics, commt } = snapshot.val();
    const { key: _id } = snapshot;

    const form = {
      _id,
      name,
      thumbnail,
      descrp,
      goals,
      topics,
      commt,
    };
    return form;
  };
}

Fire.shared = new Fire();
export default Fire;
